#include <arduino.h>

#ifndef SEQ_TUNING_H_
#define SEQ_TUNING_H_

//******************** pulse sequence sub routine *******************//
int16_t compileTuning();
#endif
